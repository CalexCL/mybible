@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_ICON_PATCH.ps1"
echo.
pause
